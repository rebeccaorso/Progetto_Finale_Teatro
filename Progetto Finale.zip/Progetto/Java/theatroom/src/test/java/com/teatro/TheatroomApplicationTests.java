package com.teatro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheatroomApplicationTests {

	@Test
	void contextLoads() {
	}

}

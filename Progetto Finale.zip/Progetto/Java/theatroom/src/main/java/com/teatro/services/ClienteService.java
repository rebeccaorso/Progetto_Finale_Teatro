package com.teatro.services;

import java.util.List;

import com.teatro.entities.Cliente;

public interface ClienteService {

	List<Cliente> getCliente();
}
